
<script src="https://cdn.tailwindcss.com"></script>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <div class="bg-white rounded overflow-hidden shadow-lg p-6 mx-4 my-4">
                        <div class="font-bold text-xl mb-2">{{ $sertifikat->name }}</div>
                        <p class="text-gray-700 text-base">{{ $sertifikat->keterangan }}</p>
                        <p class="text-gray-700 text-base">{{ $sertifikat->tanggal }}</p>
                    </div>

                    <a href="" class="inline-flex items-center px-4 py-2 bg-blue-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150 md-3">
                        Add Users
                    </a>


                        <div class="relative overflow-x-auto mt-3">
                            <table class="w-full text-sm text-left rtl:text-right text-dark-500 dark:border-white-400">
                                <thead class="text-xs text-white uppercase bg-gray-50 dark:bg-gray-600 dark:text-gray-400">
                                    <tr>
                                        <th scope="col" class="px-6 py-4">
                                            Product name
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                <tr class="bg-white border-b dark:bg-gray-700 dark:border-white-600">
                                    <th scope="row" class="px-6 py-4 font-medium text-white-900 whitespace-nowrap dark:text-white">
                                        {{ __('Sertifikat ID') }}
                                    </th>
                                    <td class="px-6 py-4">
                                        {{ __('Sertifikat Name') }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ __('QR Code') }}
                                    </td>
                                </tr>
                                <tr class="bg-white border-b dark:bg-gray-700 dark:border-white-600">
                                    <th scope="row" class="px-6 py-4 font-medium text-white-900 whitespace-nowrap dark:text-white">
                                        {{ $sertifikat->id }}
                                    </th>
                                    <td class="px-6 py-4">
                                        {{ $sertifikat->name }}
                                    </td>
                                        <td> <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={{request()->getHttpHost()}}/sertifikat/{{ $sertifikat->id }}" alt=""></td>
                                    </tr>
                                </th>
                            </tbody>
                        </table>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>{{ __('User ID') }}</th>
                                    <th>{{ __('User Name') }}</th>
                                    <th>{{ __('User sebagai') }}</th>
                                    <th>{{ __('Download Sertifikat') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($sertifikat->users as $user)
                                    <tr>
                                        <td>{{ $user->id }}</td>
                                        <td>{{ $user->name }}</td>
                                        <td>{{  DB::table('user_sertifikats')
                                            ->where('user_id', $user->id)
                                            ->where('sertifikat_id', $sertifikat->id)
                                            ->get()
                                            ->first()->sebagai }}</td>
                                        <td><a href="{{ route('sertifikat.download', $user->id.'-'.$sertifikat->id) }}" target="_blank">Download</a></td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                </div>
            </div>
        </div>
    </div>

