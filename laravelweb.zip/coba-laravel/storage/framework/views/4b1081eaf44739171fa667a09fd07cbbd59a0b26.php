<script src="https://cdn.tailwindcss.com"></script>
          <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(__('Sertifikat Name')); ?></th>

                    <th><?php echo e(__('QR Code')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sertifikats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sertifikat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
      <a href="<?php echo e(route('sertifikat.show', $sertifikat->id)); ?>" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700">
        <?php echo e($sertifikat->name); ?>

        <button type="button" class="btn btn-primary btn-lg mt-5">contoh</button>
        
     </a>   
</td> 
                          <td><img src="htpps://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo e($sertifikat->name); ?>" alt=""></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                      </table><?php /**PATH D:\applications\coba-laravel\resources\views/sertifikat/index.blade.php ENDPATH**/ ?>