

<?php $__env->startSection('container'); ?>

<div class="container">
  <div class="row my-3">
    <div class="col-lg-8">
    <h1 class="mb-3"><?php echo e($post->title); ?></h1> 

    <a href="/dashboard/posts" class="btn btn-success mb-3"><span data-feather="arrow-left"></span>Back to all my posts</a>
    <a href="/dashboard/posts/<?php echo e($post->slug); ?>/edit" class="btn btn-warning mb-3"><span data-feather="edit"></span>Edit</a>
    <form action="/dashboard/posts/<?php echo e($post->slug); ?>" method="post" class="d-inline">
      <?php echo method_field('delete'); ?>
      <?php echo csrf_field(); ?> 
      <button class="btn btn-danger mb-3" onclick="return confirm('Are you sure?')"><span data-feather="x-circle"></span> Delete</button>
    </form>

    <?php if($post->image): ?>
    <div style="max-height: 350px; overflow:hidden;">
    <img src="<?php echo e(asset('storage/' . $post->image)); ?> " class="card-img-top" alt=" $post->category->name  }}" class="img-fluid mt-3">
    </div>
    <?php else: ?>
    <img src="https://source.unsplash.com/random/1200x400?<?php echo e($post->category->name); ?>" class="card-img-top" alt="<?php echo e($post->category->name); ?>" class="img-fluid mt-3">
    <?php endif; ?>
   
    <article class="my-3 fs-5">
      <?php echo $post->body; ?>

    </article>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script>

<script src="/js/dashboard.js"></script>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\applications\coba-laravel\resources\views/dashboard/posts/show.blade.php ENDPATH**/ ?>