
<script src="https://cdn.tailwindcss.com"></script>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <div class="bg-white rounded overflow-hidden shadow-lg p-6 mx-4 my-4">
                        <div class="font-bold text-xl mb-2"><?php echo e($sertifikat->name); ?></div>
                        <p class="text-gray-700 text-base"><?php echo e($sertifikat->keterangan); ?></p>
                        <p class="text-gray-700 text-base"><?php echo e($sertifikat->tanggal); ?></p>
                    </div>

                    <a href="" class="inline-flex items-center px-4 py-2 bg-blue-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring ring-blue-300 disabled:opacity-25 transition ease-in-out duration-150 md-3">
                        Add Users
                    </a>


                        <div class="relative overflow-x-auto mt-3">
                            <table class="w-full text-sm text-left rtl:text-right text-dark-500 dark:border-white-400">
                                <thead class="text-xs text-white uppercase bg-gray-50 dark:bg-gray-600 dark:text-gray-400">
                                    <tr>
                                        <th scope="col" class="px-6 py-4">
                                            Product name
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                <tr class="bg-white border-b dark:bg-gray-700 dark:border-white-600">
                                    <th scope="row" class="px-6 py-4 font-medium text-white-900 whitespace-nowrap dark:text-white">
                                        <?php echo e(__('Sertifikat ID')); ?>

                                    </th>
                                    <td class="px-6 py-4">
                                        <?php echo e(__('Sertifikat Name')); ?>

                                    </td>
                                    <td class="px-6 py-4">
                                        <?php echo e(__('QR Code')); ?>

                                    </td>
                                </tr>
                                <tr class="bg-white border-b dark:bg-gray-700 dark:border-white-600">
                                    <th scope="row" class="px-6 py-4 font-medium text-white-900 whitespace-nowrap dark:text-white">
                                        <?php echo e($sertifikat->id); ?>

                                    </th>
                                    <td class="px-6 py-4">
                                        <?php echo e($sertifikat->name); ?>

                                    </td>
                                        <td> <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo e(request()->getHttpHost()); ?>/sertifikat/<?php echo e($sertifikat->id); ?>" alt=""></td>
                                    </tr>
                                </th>
                            </tbody>
                        </table>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('User ID')); ?></th>
                                    <th><?php echo e(__('User Name')); ?></th>
                                    <th><?php echo e(__('User sebagai')); ?></th>
                                    <th><?php echo e(__('Download Sertifikat')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sertifikat->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e(DB::table('user_sertifikats')
                                            ->where('user_id', $user->id)
                                            ->where('sertifikat_id', $sertifikat->id)
                                            ->get()
                                            ->first()->sebagai); ?></td>
                                        <td><a href="<?php echo e(route('sertifikat.download', $user->id.'-'.$sertifikat->id)); ?>" target="_blank">Download</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                </div>
            </div>
        </div>
    </div>

<?php /**PATH D:\applications\coba-laravel\resources\views/sertifikat/show.blade.php ENDPATH**/ ?>