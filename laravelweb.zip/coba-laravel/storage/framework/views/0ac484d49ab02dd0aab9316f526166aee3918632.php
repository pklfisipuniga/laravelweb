

<?php $__env->startSection('container'); ?>
<h1>Halaman Home</h1>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\applications\coba-laravel\resources\views/home.blade.php ENDPATH**/ ?>