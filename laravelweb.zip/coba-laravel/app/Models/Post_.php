<?php

namespace App\Models;


class Post 
{
  private static $blog_posts = [
    [
      "title" => "Judul Tulisan Pertama",
      "slug" => "judul-tulisan-pertama",
      "body" => "Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, reiciendis? Aut laudantium vero accusantium et enim neque exercitationem, laboriosam corporis consequuntur officia, voluptate sed incidunt ea eaque, deleniti praesentium porro. Totam omnis error ducimus voluptatum, incidunt explicabo recusandae beatae? Labore, nemo odit. Magni, saepe provident delectus maiores vel omnis perferendis iste explicabo eos autem optio illum nostrum neque unde veritatis ducimus sunt exercitationem deleniti! Atque, minima vel? Iste doloribus alias, eveniet vel magni similique, neque minus repellat possimus voluptatem quasi."
   ],
   [
      "title" => "Judul Tulisan Kedua",
      "slug" => "judul-tulisan-kedua",
      "body" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repellendus eligendi deserunt animi, recusandae perferendis architecto modi molestiae, eaque accusantium mollitia, provident culpa iure error placeat veritatis molestias odit nisi earum quaerat. Est eaque reiciendis iste, eius ab atque itaque nisi aliquam dicta facilis fugit magni hic harum corporis adipisci suscipit quos omnis dolorum repellat? Suscipit aliquam mollitia voluptate soluta pariatur ducimus rem, enim cupiditate. Quasi dolore nulla perspiciatis, distinctio dolorem debitis facilis nobis aliquid. Consequuntur, suscipit aliquid optio aspernatur impedit tempore illum itaque laboriosam. Suscipit velit, repudiandae ratione culpa harum commodi atque, officiis itaque ullam hic, corporis exercitationem labore rem."
   ],
   ];

   public static function all()
   {
    return collect(self::$blog_posts); 
   }

   public static function find($slug)
   {

    $posts = static::all();
    return $posts->firstWhere('slug', $slug);

   }
}
